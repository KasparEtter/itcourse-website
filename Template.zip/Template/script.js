'use strict'; // This line asks the browser to be more strict about your code, such as not allowing you to use undeclared variables.

function clickHandler() {
  let message = document.getElementById('message');
  message.textContent = 'You clicked the button!';
}

function initializer() {
  let button = document.getElementById('button');
  button.addEventListener('click', clickHandler);

  console.log('The content has been loaded.');
}

// Wait for the Document Object Model (DOM) to be fully loaded so that all elements can be referenced.
window.addEventListener('DOMContentLoaded', initializer);
