'use strict';

function returnTheBiggerNumber(a, b) {
  if (a > b) {
    return a;
  } else {
    return b;
  }
}

// This tests the function.
// After the function name comes the expected output followed by the arguments (the inputs).
// Please don't change these tests.
test(returnTheBiggerNumber, 5, 3, 5); // This means: Test whether returnTheBiggerNumber(3, 5) === 5
test(returnTheBiggerNumber, 5, 5, 3);
test(returnTheBiggerNumber, 5, 5, 5);
test(returnTheBiggerNumber, 4, -5, 4);


// You can assume that the array is not empty.
function returnLargestNumber(array) {
  let largestNumber = array[0];
  let i = 1;
  while (i < array.length) {
    if (array[i] > largestNumber) {
      largestNumber = array[i];
    }
    i = i + 1;
  }
  return largestNumber;
}

test(returnLargestNumber, 5, [1, 2, 3, 4, 5]);
test(returnLargestNumber, 7, [0, 4, 7, -2]);
test(returnLargestNumber, 2, [2]);


// You can assume that the array is not empty.
function returnAverage(array) {
  let sum = 0;
  let i = 0;
  while (i < array.length) {
    sum = sum + array[i];
    i = i + 1;
  }
  return sum / array.length;
}

test(returnAverage, 3, [1, 2, 3, 4, 5]);
test(returnAverage, 5, [4, 2, 9, 4, 6]);
test(returnAverage, 0, [-2, 0, 2]);
test(returnAverage, 1, [1]);


// You can assume that the string is not empty.
// The following built-in functions might be useful:
// - https://www.w3schools.com/jsref/jsref_charat.asp
// - https://www.w3schools.com/jsref/jsref_substring.asp
// - https://www.w3schools.com/jsref/jsref_touppercase.asp
function upperCaseFirstLetter(word) {
  let firstChar = word.charAt(0);
  let restOfWord = word.substring(1);
  return firstChar.toUpperCase() + restOfWord;
}

test(upperCaseFirstLetter, "Hello", "hello");
test(upperCaseFirstLetter, "A", "a");
test(upperCaseFirstLetter, "HELLO", "hELLO");
test(upperCaseFirstLetter, "123abc", "123abc");


function isEven(value) {
  return value % 2 === 0;
}

test(isEven, true, 2);
test(isEven, false, 3);
test(isEven, true, 0);
test(isEven, true, -2);
test(isEven, false, -3);


function returnAbsoluteDifference(a, b) {
  if (a > b) {
    return a - b;
  } else {
    return b - a;
  }
}

test(returnAbsoluteDifference, 5, 3, 8);
test(returnAbsoluteDifference, 5, 8, 3);
test(returnAbsoluteDifference, 0, 5, 5);
test(returnAbsoluteDifference, 10, -5, 5);
test(returnAbsoluteDifference, 10, 5, -5);


// Return -1 if the value is not in the array.
function returnFirstIndexOfValue(array, value) {
  let i = 0;
  while (i < array.length) {
    if (array[i] === value) {
      return i;
    }
    i = i + 1;
  }
  return -1;
}

test(returnFirstIndexOfValue, 2, [1, 2, 3, 4, 5], 3);
test(returnFirstIndexOfValue, 0, [1, 2, 3, 4, 5], 1);
test(returnFirstIndexOfValue, -1, [1, 2, 3, 4, 5], 6);
test(returnFirstIndexOfValue, 1, [1, 2, 2, 3], 2);
test(returnFirstIndexOfValue, -1, [], 1);


function countOccurrences(array, value) {
  let count = 0;
  let i = 0;
  while (i < array.length) {
    if (array[i] === value) {
      count = count + 1;
    }
    i = i + 1;
  }
  return count;
}

test(countOccurrences, 3, [1, 2, 2, 3, 2], 2);
test(countOccurrences, 0, [1, 2, 3, 4, 5], 6);
test(countOccurrences, 1, [1, 2, 3, 4, 5], 1);
test(countOccurrences, 0, [], 1);
test(countOccurrences, 3, [1, 1, 1], 1);


// Make sure to ignore multiples spaces (empty words).
// Useful: https://www.w3schools.com/jsref/jsref_split.asp
function returnWordCount(sentence) {
  let words = sentence.split(" ");
  let count = 0;
  let i = 0;
  while (i < words.length) {
    if (words[i].length > 0) {
      count = count + 1;
    }
    i = i + 1;
  }
  return count;
}

test(returnWordCount, 3, "hello world test");
test(returnWordCount, 1, "hello");
test(returnWordCount, 0, "");
test(returnWordCount, 0, " ");
test(returnWordCount, 4, "a b c d");
test(returnWordCount, 2, "hello  world");


function reverseString(word) {
  let reversed = "";
  let i = word.length - 1;
  while (i >= 0) {
    reversed = reversed + word.charAt(i);
    i = i - 1;
  }
  return reversed;
}

test(reverseString, "olleh", "hello");
test(reverseString, "", "");
test(reverseString, "a", "a");
test(reverseString, "123", "321");
test(reverseString, "racecar", "racecar");


// https://en.wiktionary.org/wiki/Appendix:English_palindromes
function isPalindrome(word) {
  let left = 0;
  let right = word.length - 1;
  while (left < right) {
    if (word.charAt(left) !== word.charAt(right)) {
      return false;
    }
    left = left + 1;
    right = right - 1;
  }
  return true;
}

test(isPalindrome, true, "racecar");
test(isPalindrome, false, "hello");
test(isPalindrome, true, "");
test(isPalindrome, true, "a");
test(isPalindrome, true, "aa");
test(isPalindrome, false, "ab");


function returnLengthOfLongestWord(sentence) {
  let words = sentence.split(" ");
  let maxLength = 0;
  let i = 0;
  while (i < words.length) {
    let word = words[i];
    if (word.length > maxLength) {
      maxLength = word.length;
    }
    i = i + 1;
  }
  return maxLength;
}

test(returnLengthOfLongestWord, 5, "hello world test");
test(returnLengthOfLongestWord, 5, "hello");
test(returnLengthOfLongestWord, 0, "");
test(returnLengthOfLongestWord, 1, "a b c");
test(returnLengthOfLongestWord, 12, "short verylongword");


// You can assume that the array contains at least two numbers and that all numbers are different.
function returnSecondLargestNumber(array) {
  let largest = array[0];
  let secondLargest = array[1];
  if (secondLargest > largest) {
    let temporary = largest;
    largest = secondLargest;
    secondLargest = temporary;
  }
  let i = 2;
  while (i < array.length) {
    if (array[i] > largest) {
      secondLargest = largest;
      largest = array[i];
    } else if (array[i] > secondLargest) {
      secondLargest = array[i];
    }
    i = i + 1;
  }
  return secondLargest;
}

test(returnSecondLargestNumber, 5, [5, 6]);
test(returnSecondLargestNumber, 5, [6, 5]);
test(returnSecondLargestNumber, 4, [1, 2, 3, 4, 5]);
test(returnSecondLargestNumber, 4, [5, 3, 1, 2, 4]);


// You can assume that the array contains at least two numbers.
// The numbers don't have to be strictly ascending.
function isInAscendingOrder(array) {
  let i = 1;
  while (i < array.length) {
    if (array[i - 1] > array[i]) {
      return false;
    }
    i = i + 1;
  }
  return true;
}

test(isInAscendingOrder, true, [1, 2, 3, 4, 5]);
test(isInAscendingOrder, false, [5, 4, 3, 2, 1]);
test(isInAscendingOrder, false, [1, 3, 2, 4]);
test(isInAscendingOrder, true, [1, 1]);


function convertFahrenheitToCelsius(value) {
  return (value - 32) * 5 / 9;
}

test(convertFahrenheitToCelsius, 0, 32);
test(convertFahrenheitToCelsius, 100, 212);
test(convertFahrenheitToCelsius, -40, -40);
test(convertFahrenheitToCelsius, 37, 98.6);


// You can assume that the value is greater than 0.
// You can call a function from within the same function, which is known as recursion.
function factorial(value) {
  if (value === 1) {
    return 1;
  } else {
    return value * factorial(value - 1);
  }
}

// Alternative solution:
function factorial(value) {
  let result = 1;
  let i = 2;
  while (i <= value) {
    result = result * i;
    i = i + 1;
  }
  return result;
}

test(factorial, 1, 1);
test(factorial, 2, 2);
test(factorial, 6, 3);
test(factorial, 24, 4);
test(factorial, 120, 5);


// You can assume that the index is greater than 0.
function fibonacciNumber(index) {
  let prev = 0;
  let current = 1;
  let i = 2;
  while (i <= index) {
    let next = prev + current;
    prev = current;
    current = next;
    i = i + 1;
  }
  return current;
}

test(fibonacciNumber, 1, 1);
test(fibonacciNumber, 1, 2);
test(fibonacciNumber, 2, 3);
test(fibonacciNumber, 3, 4);
test(fibonacciNumber, 5, 5);
test(fibonacciNumber, 8, 6);


function returnNumberOfTrailingZeros(value) {
  if (value === 0) {
    return 0;
  }
  let count = 0;
  while (value % 10 === 0) {
    count = count + 1;
    value = value / 10;
  }
  return count;
}

test(returnNumberOfTrailingZeros, 1, 40);
test(returnNumberOfTrailingZeros, 2, 500);
test(returnNumberOfTrailingZeros, 3, 6000);
test(returnNumberOfTrailingZeros, 0, 123);
test(returnNumberOfTrailingZeros, 0, 0);
test(returnNumberOfTrailingZeros, 1, -10);


// The following built-in functions might be useful:
// - https://www.w3schools.com/jsref/jsref_charcodeat.asp
// - https://www.w3schools.com/jsref/jsref_fromcharcode.asp
function caesarCipher(input, offset) {
  let result = "";
  let i = 0;
  while (i < input.length) {
    let char = input.charAt(i);
    if (char >= "a" && char <= "z") {
      let code = char.charCodeAt(0) - "a".charCodeAt(0);
      code = (code + offset) % 26;
      if (code < 0) {
        code = code + 26;
      }
      result = result + String.fromCharCode(code + "a".charCodeAt(0));
    } else if (char >= "A" && char <= "Z") {
      let code = char.charCodeAt(0) - "A".charCodeAt(0);
      code = (code + offset) % 26;
      if (code < 0) {
        code = code + 26;
      }
      result = result + String.fromCharCode(code + "A".charCodeAt(0));
    } else {
      result = result + char;
    }
    i = i + 1;
  }
  return result;
}

test(caesarCipher, "khoor", "hello", 3);
test(caesarCipher, "hello", "khoor", -3);
test(caesarCipher, "abc", "xyz", 3);
test(caesarCipher, "xyz", "abc", -3);
test(caesarCipher, "Hello World!", "Khoor Zruog!", -3);


// Example: "aaabb" → "3a2b"
function runLengthEncoding(input) {
  if (input === "") {
    return "";
  }
  let result = "";
  let currentChar = input.charAt(0);
  let count = 1;
  let i = 1;
  while (i < input.length) {
    if (input.charAt(i) === currentChar) {
      count = count + 1;
    } else {
      result = result + count + currentChar;
      currentChar = input.charAt(i);
      count = 1;
    }
    i = i + 1;
  }
  result = result + count + currentChar;
  return result;
}

test(runLengthEncoding, "3a2b", "aaabb");
test(runLengthEncoding, "1a", "a");
test(runLengthEncoding, "", "");
test(runLengthEncoding, "4a", "aaaa");
test(runLengthEncoding, "1a1b1c", "abc");
test(runLengthEncoding, "2a1b2a", "aabaa");


// You can assume that the value is greater than 0.
function isPrime(value) {
  if (value < 2) {
    return false;
  }
  if (value === 2) {
    return true;
  }
  if (value % 2 === 0) {
    return false;
  }
  let factor = 3;
  while (factor * factor <= value) {
    if (value % factor === 0) {
      return false;
    }
    factor = factor + 2;
  }
  return true;
}

test(isPrime, false, 1);
test(isPrime, true, 2);
test(isPrime, true, 3);
test(isPrime, false, 4);
test(isPrime, true, 5);
test(isPrime, false, 6);
test(isPrime, true, 7);
test(isPrime, false, 8);
test(isPrime, false, 9);
test(isPrime, false, 10);
test(isPrime, true, 11);
test(isPrime, true, 13);
test(isPrime, false, 15);
test(isPrime, true, 17);
test(isPrime, true, 19);
test(isPrime, false, 21);


// You can use a JavaScript object as a lookup table.
function convertRomanToInteger(roman) {
  let values = {
    "I": 1,
    "V": 5,
    "X": 10,
    "L": 50,
    "C": 100,
    "D": 500,
    "M": 1000
  };
  
  let result = 0;
  let i = 0;
  while (i < roman.length) {
    let current = values[roman.charAt(i)];
    let next = (i + 1 < roman.length) ? values[roman.charAt(i + 1)] : 0;
    
    if (current < next) {
      result = result + next - current;
      i = i + 2;
    } else {
      result = result + current;
      i = i + 1;
    }
  }
  return result;
}

test(convertRomanToInteger, 1, "I");
test(convertRomanToInteger, 5, "V");
test(convertRomanToInteger, 10, "X");
test(convertRomanToInteger, 50, "L");
test(convertRomanToInteger, 100, "C");
test(convertRomanToInteger, 500, "D");
test(convertRomanToInteger, 1000, "M");
test(convertRomanToInteger, 4, "IV");
test(convertRomanToInteger, 9, "IX");
test(convertRomanToInteger, 40, "XL");
test(convertRomanToInteger, 90, "XC");
test(convertRomanToInteger, 400, "CD");
test(convertRomanToInteger, 600, "DC");
test(convertRomanToInteger, 900, "CM");
test(convertRomanToInteger, 3, "III");
test(convertRomanToInteger, 58, "LVIII");
test(convertRomanToInteger, 1994, "MCMXCIV");


updateProgress();
