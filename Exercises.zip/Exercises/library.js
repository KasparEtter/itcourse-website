// See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Statements/const for the syntax: const variable = value;
const testsDiv = document.getElementById("tests");

// Outputs text to the page
function write(text, color) {
  const p = document.createElement("p");
  p.textContent = text;
  p.style.color = color;
  testsDiv.appendChild(p);
}

let passedTests = 0;
let failedTests = 0;
let unimplementedTests = 0;

// See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Functions/rest_parameters for the syntax: function name(...variable)
function test(exerciseFunction, expectedOutput, ...testArguments) {
  const result = exerciseFunction(...testArguments);
  if (result === undefined) {
    unimplementedTests = unimplementedTests + 1;
  } else {
    write(
      // See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Template_literals for the syntax: `${variable}`
      `${exerciseFunction.name}(${testArguments.map(arg => JSON.stringify(arg)).join(", ")}) === ${JSON.stringify(result)} ${result === expectedOutput ? "" : "→ " + JSON.stringify(expectedOutput)}`,
      // See https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Operators/Conditional_operator for the syntax: condition ? valueIfTrue : valueIfFalse
      result === expectedOutput ? "green" : "red",
    );
    if (result === expectedOutput) {
      passedTests = passedTests + 1;
    } else {
      failedTests = failedTests + 1;
    }
  }
}

function updateProgress() {
  const total = passedTests + failedTests + unimplementedTests;
  const passedPercent = total ? (passedTests / total) * 100 : 0;
  const failedPercent = total ? (failedTests / total) * 100 : 0;
  const unimplementedPercent = total ? (unimplementedTests / total) * 100 : 0;
  document.getElementById("progress-passed").style.width = passedPercent + "%";
  document.getElementById("progress-failed").style.width = failedPercent + "%";
  document.getElementById("progress-unimplemented").style.width = unimplementedPercent + "%";
}
