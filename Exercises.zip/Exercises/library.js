const testsDiv = document.getElementById("tests");

// Outputs text to the page
function write(text, color = "black") {
  const p = document.createElement("p");
  p.textContent = text;
  p.style.color = color;
  testsDiv.appendChild(p);
}

let passedTests = 0;
let failedTests = 0;
let unimplementedTests = 0;

function test(func, expected, ...args) {
  const result = func(...args);
  if (result === undefined) {
    unimplementedTests++;
  } else {
    write(
      `${func.name}(${args.map(arg => JSON.stringify(arg)).join(", ")}) === ${JSON.stringify(result)} ${result === expected ? "" : "→ " + JSON.stringify(expected)}`,
      result === expected ? "green" : "red",
    );
    if (result === expected) {
      passedTests++;
    } else {
      failedTests++;
    }
  }
}

function updateProgress() {
  const total = passedTests + failedTests + unimplementedTests;
  const passedPercent = total ? (passedTests / total) * 100 : 0;
  const failedPercent = total ? (failedTests / total) * 100 : 0;
  const unimplementedPercent = total ? (unimplementedTests / total) * 100 : 0;
  document.getElementById('progress-passed').style.width = passedPercent + '%';
  document.getElementById('progress-failed').style.width = failedPercent + '%';
  document.getElementById('progress-unimplemented').style.width = unimplementedPercent + '%';
}
