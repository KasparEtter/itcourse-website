'use strict'; // This line asks the browser to be more strict about your code, such as not allowing you to use undeclared variables.

// Introduction to JavaScript

// This is a comment until the end of the line.
/*
This is a comment which can span multiple lines or end before the end of the line.
*/

// While usually not necessary as long as each instruction is on a separate line,
// it's common practice to end each instruction with a semicolon (;).

/* ---------- Variable declaration and assignment ---------- */

let x; // This declares a variable called x.
x = 1; // This assigns the value 1 to the variable x.

let y = 2; // This declares a variable called y and assigns the value 2 to it right away.

// There are other data types in JavaScript, such as:
let text = "Hello, world!"; // Strings are sequences of characters, written in double (or single) quotes.
let boolean = true; // Booleans are either true or false, where true and false are so-called keywords.
let array = [1, 2, 3]; // Arrays are ordered lists of values, written in square brackets.
let object = {a: 1, b: 2, c: 3}; // Objects are collections of key-value pairs, written in curly braces.

// You can use the console.log function to print the value of a variable or the result of an expression to the console of your browser:
console.log("x:", x); // See https://developer.mozilla.org/en-US/docs/Web/API/console/log_static for more information.
console.log("x + y:", x + y); // The string in the first argument is just for labeling the output.
console.log("text:", text);

/* ---------- Operations on these data types ---------- */

// Numbers:
x + y; // Addition
x - y; // Subtraction
x * y; // Multiplication
x / y; // Division
x % y; // "Modulus" (as long as x is positive): This gives the remainder of the division of x by y.
x ** y; // Exponentiation

// Strings:
let concatenated = text + " How are you?"; // String concatenation
console.log("concatenated:", concatenated);

// Booleans (see https://en.wikipedia.org/wiki/Boolean_data_type for more information):
let a = true;
let b = false;
a && b; // Logical AND
// console.log("a && b:", a && b);
a || b; // Logical OR
// console.log("a || b:", a || b);
!a; // Logical NOT
// console.log("!a:", !a);

// Arrays and objects:
array[0]; // Access the first element of the array (the first index is 0, not 1)
object.a; // Access the property "a" of the object

// You can access the length of a string or an array via their "length" property:
text.length;
array.length;

// Question: So how can you access the last element of an array? (array[-1] doesn't work in JavaScript.)

// (If you don't assign the result of an expression to a variable, the result is lost, i.e. it can no longer be referenced.)

// Instead of using two variables, you can also combine variables with so-called literals or use only literals:
x + 1;
3 + 4;
// etc.

/* ---------- Comparison of values ---------- */

// The following operations result in a boolean value:
x === y; // Strict equality (there is also weak equality with ==, but you shouldn't use it because 2 == "2" is true, which is confusing)
x !== y; // Strict inequality (there is also weak inequality with !=, but you shouldn't use it for the same reason as above)
x > y; // Greater than
x >= y; // Greater than or equal to
x < y; // Less than
x <= y; // Less than or equal to

/* ---------- Variable re-assignment ---------- */

// You can re-assign existing variables, which then store the new value from now on:
x = 3;
text = "new";

console.log("x:", x);
console.log("text:", text);

// You can also re-assign elements of an array or properties of an object:
array[0] = 4;
object.a = 5;

/* ---------- Functions and variable shadowing ---------- */

// You can declare a function as follows:
function sum(a, b) { // "sum" is the name of the function, "a" and "b" its arguments. (These names are freely choosable.)
  return a + b; // "return" returns the result of the expression which follows it and stops the execution of the function.
} // The curly braces ({ and }) mark the beginning and end of the function body. Make sure to include them!

// And then use it as follows:
console.log("sum(3, 4):", sum(3, 4));

// Variables declared inside a code block, such as a function body, are not accessible outside of it.
// When you declare a variable inside a code block with a name which already exists outside of the code block,
// then the variable inside the code block "shadows" the variable outside of the code block,
// which means that you can no longer access the outer variable from inside the code block
// and the value of the outer variable will not be affected by assignments to the inner variable.

let z = 42;
{
  x = x + 1; // Outer variables are still accessible and modifiable inside a code block.
  console.log("x inside code block:", x);
  let z; // This variable shadows the outer variable z.
  z = "secret"; // This assigns the value "secret" to the inner variable z, not the outer variable z.
  console.log("inner z:", z);
  let inside = "I'm inside!"; // This variable is only accessible inside the code block.
}
console.log("outer z:", z); // This still prints 42, because the outer variable z was not affected by the inner variable z.
// console.log("inside:", inside); // This results in an uncaught ReferenceError, because the variable 'inside' is not accessible outside of the code block.

// The arguments of a function are declared in the function declaration and then available inside the function body.
// This is why there was no name conflict when we used 'a' and 'b' as argument names in the 'sum' function above,
// even though we had already declared variables with these names outside of the function.

// The arguments of a function are initialized with the values passed to the function when it is called.
// Numbers, booleans, and strings are passed "by value", which means that the function gets its own copy of the value.
let counter = 1;
function increment(value) {
  value = value + 1; // This modifies the local copy of the argument, not the variable 'counter' outside of the function.
  return value;
}
console.log("increment(counter):", increment(counter)); // This prints 2.
console.log("counter after increment:", counter); // This still prints 1 because the variable 'counter' outside of the function was not affected.

// Arrays and objects are passed "by reference", which means that the function gets a (new) reference to the original array or object
// so that changes to the array or object inside the function also affect the original array or object outside of the function.
let pair = ["a", "b"];
function swapElements(array) {
  let temp = array[0];
  array[0] = array[1];
  array[1] = temp;
}
swapElements(pair); // This modifies the original array 'pair' outside of the function.
console.log("pair after swapElements:", pair); // This prints ["b", "a"].

// When re-assigning an array or object inside a function, the original array or object outside of the function is not affected,
// which is why the following code doesn't achieve the intended purpose:
function emptyArray(array) {
  array = []; // This re-assigns the function-local reference to a new empty array but doesn't affect the original array outside of the function.
}
emptyArray(pair);
console.log("pair after emptyArray:", pair); // This still prints ["b", "a"].

// Some built-in functions are accessed like properties of an object:
array.push(4); // This is how you add an element to an array.
console.log("array after push:", array); // console.log is another example of accessing a function like a property of an object.

/* ---------- Control flow with if-statements and loops ---------- */

// You can use an if-statement to execute the instructions inside curly braces only if a condition is true:
if (x > y) {
  console.log("x is greater than y");
} else {
  if (x === y) {
    console.log("x and y are equal");
  } else {
    console.log("x is less than y");
  }
}

// Important: Always use curly braces and indent the code inside them correctly, which helps you avoid syntax errors and mistakes.
// (You can increase the indentation level of selected lines by pressing Tab and decrease it by pressing Shift+Tab in most code editors.)

// You can use a while-loop to execute the instructions inside curly braces while a condition is true:
let i = 0; // Remember: Array indices start at 0, not 1.
while (i < array.length) { // Since the last index of an array is array.length - 1, the condition is i < array.length, not i <= array.length.
  // This is how you loop over the elements of an array.
  console.log("array[" + i + "]:", array[i]);
  i = i + 1; // Make sure that the condition is false at some point, otherwise you have an infinite loop.
}

/* ---------- Exercises ---------- */

console.log("All console outputs from here on are from the exercises.");

// Now it's your turn: Implement the following functions (the TODOs).
// You can check your progress by reloading the page in the browser.


function returnTheBiggerNumber(a, b) {
  // TODO
}

// This tests the function.
// After the function name comes the expected output followed by the arguments (the inputs).
// Please don't change these tests.
test(returnTheBiggerNumber, 5, 3, 5); // This means: Test whether returnTheBiggerNumber(3, 5) === 5
test(returnTheBiggerNumber, 5, 5, 3);
test(returnTheBiggerNumber, 5, 5, 5);
test(returnTheBiggerNumber, 4, -5, 4);


// You can assume that the array is not empty.
function returnLargestNumber(array) {
  // TODO
}

test(returnLargestNumber, 5, [1, 2, 3, 4, 5]);
test(returnLargestNumber, 7, [0, 4, 7, -2]);
test(returnLargestNumber, 2, [2]);


// You can assume that the array is not empty.
function returnAverage(array) {
  // TODO
}

test(returnAverage, 3, [1, 2, 3, 4, 5]);
test(returnAverage, 5, [4, 2, 9, 4, 6]);
test(returnAverage, 0, [-2, 0, 2]);
test(returnAverage, 1, [1]);


// You can assume that the string is not empty.
// The following built-in functions might be useful:
// - https://www.w3schools.com/jsref/jsref_charat.asp
// - https://www.w3schools.com/jsref/jsref_substring.asp
// - https://www.w3schools.com/jsref/jsref_touppercase.asp
function upperCaseFirstLetter(word) {
  // TODO
}

test(upperCaseFirstLetter, "Hello", "hello");
test(upperCaseFirstLetter, "A", "a");
test(upperCaseFirstLetter, "HELLO", "hELLO");
test(upperCaseFirstLetter, "123abc", "123abc");


function isEven(value) {
  // TODO
}

test(isEven, true, 2);
test(isEven, false, 3);
test(isEven, true, 0);
test(isEven, true, -2);
test(isEven, false, -3);


function returnAbsoluteDifference(a, b) {
  // TODO
}

test(returnAbsoluteDifference, 5, 3, 8);
test(returnAbsoluteDifference, 5, 8, 3);
test(returnAbsoluteDifference, 0, 5, 5);
test(returnAbsoluteDifference, 10, -5, 5);
test(returnAbsoluteDifference, 10, 5, -5);


// Return -1 if the value is not in the array.
function returnFirstIndexOfValue(array, value) {
  // TODO
}

test(returnFirstIndexOfValue, 2, [1, 2, 3, 4, 5], 3);
test(returnFirstIndexOfValue, 0, [1, 2, 3, 4, 5], 1);
test(returnFirstIndexOfValue, -1, [1, 2, 3, 4, 5], 6);
test(returnFirstIndexOfValue, 1, [1, 2, 2, 3], 2);
test(returnFirstIndexOfValue, -1, [], 1);


function countOccurrences(array, value) {
  // TODO
}

test(countOccurrences, 3, [1, 2, 2, 3, 2], 2);
test(countOccurrences, 0, [1, 2, 3, 4, 5], 6);
test(countOccurrences, 1, [1, 2, 3, 4, 5], 1);
test(countOccurrences, 0, [], 1);
test(countOccurrences, 3, [1, 1, 1], 1);


// Make sure to ignore multiples spaces (empty words).
// Useful: https://www.w3schools.com/jsref/jsref_split.asp
function returnWordCount(sentence) {
  // TODO
}

test(returnWordCount, 3, "hello world test");
test(returnWordCount, 1, "hello");
test(returnWordCount, 0, "");
test(returnWordCount, 0, " ");
test(returnWordCount, 4, "a b c d");
test(returnWordCount, 2, "hello  world");


function reverseString(word) {
  // TODO
}

test(reverseString, "olleh", "hello");
test(reverseString, "", "");
test(reverseString, "a", "a");
test(reverseString, "123", "321");
test(reverseString, "racecar", "racecar");


// https://en.wiktionary.org/wiki/Appendix:English_palindromes
function isPalindrome(word) {
  // TODO
}

test(isPalindrome, true, "racecar");
test(isPalindrome, false, "hello");
test(isPalindrome, true, "");
test(isPalindrome, true, "a");
test(isPalindrome, true, "aa");
test(isPalindrome, false, "ab");


function returnLengthOfLongestWord(sentence) {
  // TODO
}

test(returnLengthOfLongestWord, 5, "hello world test");
test(returnLengthOfLongestWord, 5, "hello");
test(returnLengthOfLongestWord, 0, "");
test(returnLengthOfLongestWord, 1, "a b c");
test(returnLengthOfLongestWord, 12, "short verylongword");


// You can assume that the array contains at least two numbers and that all numbers are different.
function returnSecondLargestNumber(array) {
  // TODO
}

test(returnSecondLargestNumber, 5, [5, 6]);
test(returnSecondLargestNumber, 5, [6, 5]);
test(returnSecondLargestNumber, 4, [1, 2, 3, 4, 5]);
test(returnSecondLargestNumber, 4, [5, 3, 1, 2, 4]);


// You can assume that the array contains at least two numbers.
// The numbers don't have to be strictly ascending.
function isInAscendingOrder(array) {
  // TODO
}

test(isInAscendingOrder, true, [1, 2, 3, 4, 5]);
test(isInAscendingOrder, false, [5, 4, 3, 2, 1]);
test(isInAscendingOrder, false, [1, 3, 2, 4]);
test(isInAscendingOrder, true, [1, 1]);


function convertFahrenheitToCelsius(value) {
  // TODO
}

test(convertFahrenheitToCelsius, 0, 32);
test(convertFahrenheitToCelsius, 100, 212);
test(convertFahrenheitToCelsius, -40, -40);
test(convertFahrenheitToCelsius, 37, 98.6);


// You can assume that the value is greater than 0.
// You can call a function from within the same function, which is known as recursion.
function factorial(value) {
  // TODO
}

test(factorial, 1, 1);
test(factorial, 2, 2);
test(factorial, 6, 3);
test(factorial, 24, 4);
test(factorial, 120, 5);


// You can assume that the index is greater than 0.
function fibonacciNumber(index) {
  // TODO
}

test(fibonacciNumber, 1, 1);
test(fibonacciNumber, 1, 2);
test(fibonacciNumber, 2, 3);
test(fibonacciNumber, 3, 4);
test(fibonacciNumber, 5, 5);
test(fibonacciNumber, 8, 6);


function returnNumberOfTrailingZeros(value) {
  // TODO
}

test(returnNumberOfTrailingZeros, 1, 40);
test(returnNumberOfTrailingZeros, 2, 500);
test(returnNumberOfTrailingZeros, 3, 6000);
test(returnNumberOfTrailingZeros, 0, 123);
test(returnNumberOfTrailingZeros, 0, 0);
test(returnNumberOfTrailingZeros, 1, -10);


// The following built-in functions might be useful:
// - https://www.w3schools.com/jsref/jsref_charcodeat.asp
// - https://www.w3schools.com/jsref/jsref_fromcharcode.asp
function caesarCipher(input, offset) {
  // TODO
}

test(caesarCipher, "khoor", "hello", 3);
test(caesarCipher, "hello", "khoor", -3);
test(caesarCipher, "abc", "xyz", 3);
test(caesarCipher, "xyz", "abc", -3);
test(caesarCipher, "Hello World!", "Khoor Zruog!", -3);


// Example: "aaabb" → "3a2b"
function runLengthEncoding(input) {
  // TODO
}

test(runLengthEncoding, "3a2b", "aaabb");
test(runLengthEncoding, "1a", "a");
test(runLengthEncoding, "", "");
test(runLengthEncoding, "4a", "aaaa");
test(runLengthEncoding, "1a1b1c", "abc");
test(runLengthEncoding, "2a1b2a", "aabaa");


// You can assume that the value is greater than 0.
function isPrime(value) {
  // TODO
}

test(isPrime, false, 1);
test(isPrime, true, 2);
test(isPrime, true, 3);
test(isPrime, false, 4);
test(isPrime, true, 5);
test(isPrime, false, 6);
test(isPrime, true, 7);
test(isPrime, false, 8);
test(isPrime, false, 9);
test(isPrime, false, 10);
test(isPrime, true, 11);
test(isPrime, true, 13);
test(isPrime, false, 15);
test(isPrime, true, 17);
test(isPrime, true, 19);
test(isPrime, false, 21);


// You can use a JavaScript object as a lookup table.
function convertRomanToInteger(roman) {
  let values = {
    "I": 1,
    "V": 5,
    "X": 10,
    "L": 50,
    "C": 100,
    "D": 500,
    "M": 1000
  };
  
  // TODO
}

test(convertRomanToInteger, 1, "I");
test(convertRomanToInteger, 5, "V");
test(convertRomanToInteger, 10, "X");
test(convertRomanToInteger, 50, "L");
test(convertRomanToInteger, 100, "C");
test(convertRomanToInteger, 500, "D");
test(convertRomanToInteger, 1000, "M");
test(convertRomanToInteger, 4, "IV");
test(convertRomanToInteger, 9, "IX");
test(convertRomanToInteger, 40, "XL");
test(convertRomanToInteger, 90, "XC");
test(convertRomanToInteger, 400, "CD");
test(convertRomanToInteger, 600, "DC");
test(convertRomanToInteger, 900, "CM");
test(convertRomanToInteger, 3, "III");
test(convertRomanToInteger, 58, "LVIII");
test(convertRomanToInteger, 1994, "MCMXCIV");


updateProgress();
