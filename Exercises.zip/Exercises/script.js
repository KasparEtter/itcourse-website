'use strict'; // This line asks the browser to be more strict about your code, such as not allowing you to use undeclared variables.

// Introduction to JavaScript

// This is a comment until the end of the line.
/*
This is a comment which can span multiple lines or end before the end of the line.
*/

// While usually not necessary as long as each instruction is on a separate line,
// it's common pratice to end each instruction with a semicolon (;).

let x; // This declares a variable called x.
x = 1; // This assigns the value 1 to the variable x.

let y = 2; // This declares a variable called y and assigns the value 2 to it right away.

// There are other data types in JavaScript, such as:
let text = "Hello, world!"; // Strings are sequences of characters, written in double (or single) quotes.
let boolean = true; // Booleans are either true or false, where true and false are so-called keywords.
let array = [1, 2, 3]; // Arrays are ordered lists of values, written in square brackets.
let object = {a: 1, b: 2, c: 3}; // Objects are collections of key-value pairs, written in curly braces.

// You can operate on these data types as follows:
x + y; // Addition
x - y; // Subtraction
x * y; // Multiplication
x / y; // Division
x % y; // "Modulus" (as long as x is positive)
x ** y; // Exponentiation

text + " How are you?"; // String concatenation

let a = true;
let b = false;
a && b; // Logical AND
a || b; // Logical OR
!a; // Logical NOT

array[0]; // Access the first element of the array (the first index is 0, not 1)
object.a; // Access the property "a" of the object
object["a"] // Achieves the same (useful when the name of the propery is stored in a variable) 

// (If you don't assign the result of an expression to a variable as above, the result is lost.)

// Instead of using two variables, you can also combine variables with so-called literals or use only literals:
x + 1;
3 + 4;
// etc.

// The following operations result in a boolean value:
x === y; // Strict equality (there is also weak equality, but you shouldn't use it)
x !== y; // Strict inequality
x > y; // Greater than
x >= y; // Greater than or equal to
x < y; // Less than
x <= y; // Less than or equal to

// You can re-assign existing variables, which then store the new value from now on:
x = 3;
text = "new";

// You can also re-assign elements of an array or properties of an object:
array[0] = 4;
object.a = 5;

// You can access the length of a string or an array via their "length" property:
text.length;
array.length;

// You can declare a function as follows:
function sum(a, b) { // "sum" is the name of the function, "a" and "b" its arguments. (These names are freely choosable.)
  return a + b; // "return" returns the result of the expression which follows it.
}

// And then us it as follows:
sum(3, 4) === 7;

// Functions can be "nested" in an object just like other properties:
array.push(4); // This is how you add an element to an array.

// You can use the console.log function to print the value of a variable or the result of an expression to the console of your browser:
console.log(x);
console.log(x + y);

// You can use an if-statement to execute the instructions inside curly braces only if a condition is true:
if (x > y) {
  console.log(x);
} else if (x === y) {
  console.log("equal");
} else {
  console.log(y);
}

// You can use a while-loop to execute the instructions inside curly braces while a condition is true:
let i = 0;
while (i < 3) {
  console.log(i);
  i = i + 1; // Make sure that the condition is false at some point, otherwise you have an infinite loop.
}


// Now implement the following functions. You can check your progress by reloading the page in the browser.


function returnTheBiggerNumber(a, b) {
  // TODO
}

// This tests the function.
// After the function name comes the expected output followed by the arguments (the inputs).
// Please don't change these tests.
test(returnTheBiggerNumber, 5, 3, 5); // This means: Test whether returnTheBiggerNumber(3, 5) === 5
test(returnTheBiggerNumber, 5, 5, 3);
test(returnTheBiggerNumber, 5, 5, 5);
test(returnTheBiggerNumber, 4, -5, 4);


// You can assume that the array is not empty.
function returnLargestNumber(array) {
  // TODO
}

test(returnLargestNumber, 5, [1, 2, 3, 4, 5]);
test(returnLargestNumber, 7, [0, 4, 7, -2]);
test(returnLargestNumber, 2, [2]);


// You can assume that the array is not empty.
function returnAverage(array) {
  // TODO
}

test(returnAverage, 3, [1, 2, 3, 4, 5]);
test(returnAverage, 5, [4, 2, 9, 4, 6]);
test(returnAverage, 0, [-2, 0, 2]);
test(returnAverage, 1, [1]);


// You can assume that the string is not empty.
// The following built-in functions might be useful:
// - https://www.w3schools.com/jsref/jsref_charat.asp
// - https://www.w3schools.com/jsref/jsref_substring.asp
// - https://www.w3schools.com/jsref/jsref_touppercase.asp
function upperCaseFirstLetter(word) {
  // TODO
}

test(upperCaseFirstLetter, "Hello", "hello");
test(upperCaseFirstLetter, "A", "a");
test(upperCaseFirstLetter, "HELLO", "hELLO");
test(upperCaseFirstLetter, "123abc", "123abc");


function isEven(value) {
  // TODO
}

test(isEven, true, 2);
test(isEven, false, 3);
test(isEven, true, 0);
test(isEven, true, -2);
test(isEven, false, -3);


function returnAbsoluteDifference(a, b) {
  // TODO
}

test(returnAbsoluteDifference, 5, 3, 8);
test(returnAbsoluteDifference, 5, 8, 3);
test(returnAbsoluteDifference, 0, 5, 5);
test(returnAbsoluteDifference, 10, -5, 5);
test(returnAbsoluteDifference, 10, 5, -5);


// Return -1 if the value is not in the array.
function returnFirstIndexOfValue(array, value) {
  // TODO
}

test(returnFirstIndexOfValue, 2, [1, 2, 3, 4, 5], 3);
test(returnFirstIndexOfValue, 0, [1, 2, 3, 4, 5], 1);
test(returnFirstIndexOfValue, -1, [1, 2, 3, 4, 5], 6);
test(returnFirstIndexOfValue, 1, [1, 2, 2, 3], 2);
test(returnFirstIndexOfValue, -1, [], 1);


function countOccurrences(array, value) {
  // TODO
}

test(countOccurrences, 3, [1, 2, 2, 3, 2], 2);
test(countOccurrences, 0, [1, 2, 3, 4, 5], 6);
test(countOccurrences, 1, [1, 2, 3, 4, 5], 1);
test(countOccurrences, 0, [], 1);
test(countOccurrences, 3, [1, 1, 1], 1);


// Make sure to ignore multiples spaces (empty words).
// Useful: https://www.w3schools.com/jsref/jsref_split.asp
function returnWordCount(sentence) {
  // TODO
}

test(returnWordCount, 3, "hello world test");
test(returnWordCount, 1, "hello");
test(returnWordCount, 0, "");
test(returnWordCount, 0, " ");
test(returnWordCount, 4, "a b c d");
test(returnWordCount, 2, "hello  world");


function reverseString(word) {
  // TODO
}

test(reverseString, "olleh", "hello");
test(reverseString, "", "");
test(reverseString, "a", "a");
test(reverseString, "123", "321");
test(reverseString, "racecar", "racecar");


// https://en.wiktionary.org/wiki/Appendix:English_palindromes
function isPalindrome(word) {
  // TODO
}

test(isPalindrome, true, "racecar");
test(isPalindrome, false, "hello");
test(isPalindrome, true, "");
test(isPalindrome, true, "a");
test(isPalindrome, true, "aa");
test(isPalindrome, false, "ab");


function returnLengthOfLongestWord(sentence) {
  // TODO
}

test(returnLengthOfLongestWord, 5, "hello world test");
test(returnLengthOfLongestWord, 5, "hello");
test(returnLengthOfLongestWord, 0, "");
test(returnLengthOfLongestWord, 1, "a b c");
test(returnLengthOfLongestWord, 12, "short verylongword");


// You can assume that the array contains at least two numbers and that all numbers are different.
function returnSecondLargestNumber(array) {
  // TODO
}

test(returnSecondLargestNumber, 5, [5, 6]);
test(returnSecondLargestNumber, 5, [6, 5]);
test(returnSecondLargestNumber, 4, [1, 2, 3, 4, 5]);
test(returnSecondLargestNumber, 4, [5, 3, 1, 2, 4]);


// You can assume that the array contains at least two numbers.
// The numbers don't have to be strictly ascending.
function isInAscendingOrder(array) {
  // TODO
}

test(isInAscendingOrder, true, [1, 2, 3, 4, 5]);
test(isInAscendingOrder, false, [5, 4, 3, 2, 1]);
test(isInAscendingOrder, false, [1, 3, 2, 4]);
test(isInAscendingOrder, true, [1, 1]);


function convertFahrenheitToCelsius(value) {
  // TODO
}

test(convertFahrenheitToCelsius, 0, 32);
test(convertFahrenheitToCelsius, 100, 212);
test(convertFahrenheitToCelsius, -40, -40);
test(convertFahrenheitToCelsius, 37, 98.6);


// You can assume that the value is greater than 0.
// You can call a function from within the same function, which is known as recursion.
function factorial(value) {
  // TODO
}

test(factorial, 1, 1);
test(factorial, 2, 2);
test(factorial, 6, 3);
test(factorial, 24, 4);
test(factorial, 120, 5);


// You can assume that the index is greater than 0.
function fibonacciNumber(index) {
  // TODO
}

test(fibonacciNumber, 1, 1);
test(fibonacciNumber, 1, 2);
test(fibonacciNumber, 2, 3);
test(fibonacciNumber, 3, 4);
test(fibonacciNumber, 5, 5);
test(fibonacciNumber, 8, 6);


function returnNumberOfTrailingZeros(value) {
  // TODO
}

test(returnNumberOfTrailingZeros, 1, 40);
test(returnNumberOfTrailingZeros, 2, 500);
test(returnNumberOfTrailingZeros, 3, 6000);
test(returnNumberOfTrailingZeros, 0, 123);
test(returnNumberOfTrailingZeros, 0, 0);
test(returnNumberOfTrailingZeros, 1, -10);


// The following built-in functions might be useful:
// - https://www.w3schools.com/jsref/jsref_charcodeat.asp
// - https://www.w3schools.com/jsref/jsref_fromcharcode.asp
function caesarCipher(input, offset) {
  // TODO
}

test(caesarCipher, "khoor", "hello", 3);
test(caesarCipher, "hello", "khoor", -3);
test(caesarCipher, "abc", "xyz", 3);
test(caesarCipher, "xyz", "abc", -3);
test(caesarCipher, "Hello World!", "Khoor Zruog!", -3);


// Example: "aaabb" → "3a2b"
function runLengthEncoding(input) {
  // TODO
}

test(runLengthEncoding, "3a2b", "aaabb");
test(runLengthEncoding, "1a", "a");
test(runLengthEncoding, "", "");
test(runLengthEncoding, "4a", "aaaa");
test(runLengthEncoding, "1a1b1c", "abc");
test(runLengthEncoding, "2a1b2a", "aabaa");


// You can assume that the value is greater than 0.
function isPrime(value) {
  // TODO
}

test(isPrime, false, 1);
test(isPrime, true, 2);
test(isPrime, true, 3);
test(isPrime, false, 4);
test(isPrime, true, 5);
test(isPrime, false, 6);
test(isPrime, true, 7);
test(isPrime, false, 8);
test(isPrime, false, 9);
test(isPrime, false, 10);
test(isPrime, true, 11);
test(isPrime, true, 13);
test(isPrime, false, 15);
test(isPrime, true, 17);
test(isPrime, true, 19);
test(isPrime, false, 21);


// You can use a JavaScript object as a lookup table.
function convertRomanToInteger(roman) {
  let values = {
    "I": 1,
    "V": 5,
    "X": 10,
    "L": 50,
    "C": 100,
    "D": 500,
    "M": 1000
  };
  
  // TODO
}

test(convertRomanToInteger, 1, "I");
test(convertRomanToInteger, 5, "V");
test(convertRomanToInteger, 10, "X");
test(convertRomanToInteger, 50, "L");
test(convertRomanToInteger, 100, "C");
test(convertRomanToInteger, 500, "D");
test(convertRomanToInteger, 1000, "M");
test(convertRomanToInteger, 4, "IV");
test(convertRomanToInteger, 9, "IX");
test(convertRomanToInteger, 40, "XL");
test(convertRomanToInteger, 90, "XC");
test(convertRomanToInteger, 400, "CD");
test(convertRomanToInteger, 600, "DC");
test(convertRomanToInteger, 900, "CM");
test(convertRomanToInteger, 3, "III");
test(convertRomanToInteger, 58, "LVIII");
test(convertRomanToInteger, 1994, "MCMXCIV");


updateProgress();
