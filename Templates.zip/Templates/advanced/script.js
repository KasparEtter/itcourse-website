'use strict';

window.addEventListener('DOMContentLoaded', () => {
  const content = document.getElementById('content');
  const button = document.getElementById('actionButton');
  const year = document.getElementById('year');

  if (year) {
    year.textContent = new Date().getFullYear();
  }

  if (button && content) {
    button.addEventListener('click', () => {
      content.textContent = 'You clicked the button!';
    });
  }

  console.log('Script initialized');
});
