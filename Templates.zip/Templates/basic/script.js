'use strict'; // This line asks the browser to be more strict about your code, such as not allowing you to use undeclared variables.

console.log('Script loaded');
